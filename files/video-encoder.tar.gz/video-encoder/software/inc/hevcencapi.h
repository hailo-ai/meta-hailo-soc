/*------------------------------------------------------------------------------
--                                                                                                                               --
--       This software is confidential and proprietary and may be used                                   --
--        only as expressly authorized by a licensing agreement from                                     --
--                                                                                                                               --
--                            Verisilicon.                                                                                    --
--                                                                                                                               --
--                   (C) COPYRIGHT 2014 VERISILICON                                                            --
--                            ALL RIGHTS RESERVED                                                                    --
--                                                                                                                               --
--                 The entire notice above must be reproduced                                                 --
--                  on all copies and should not be removed.                                                    --
--                                                                                                                               --
--------------------------------------------------------------------------------
--
--  Abstract : H2 VC Encoder API
--
------------------------------------------------------------------------------*/

#ifndef API_H
#define API_H

#include "base_type.h"
#include "enccommon.h"

#ifdef __cplusplus
extern "C"
{
#endif
#define VCENC_MAX_REF_FRAMES 4
#define MAX_GOP_SIZE 8
#define MAX_ADAPTIVE_GOP_SIZE 8
#define MAX_GOP_PIC_CONFIG_NUM 30

  /*------------------------------------------------------------------------------
      1. Type definition for encoder instance
  ------------------------------------------------------------------------------*/
  typedef const void *VCEncInst;


  /*------------------------------------------------------------------------------
      2. Enumerations for API parameters
  ------------------------------------------------------------------------------*/

  /* Function return values */
  typedef enum
  {
    VCENC_OK = 0,
    VCENC_FRAME_READY = 1,

    VCENC_ERROR = -1,
    VCENC_NULL_ARGUMENT = -2,
    VCENC_INVALID_ARGUMENT = -3,
    VCENC_MEMORY_ERROR = -4,
    VCENC_EWL_ERROR = -5,
    VCENC_EWL_MEMORY_ERROR = -6,
    VCENC_INVALID_STATUS = -7,
    VCENC_OUTPUT_BUFFER_OVERFLOW = -8,
    VCENC_HW_BUS_ERROR = -9,
    VCENC_HW_DATA_ERROR = -10,
    VCENC_HW_TIMEOUT = -11,
    VCENC_HW_RESERVED = -12,
    VCENC_SYSTEM_ERROR = -13,
    VCENC_INSTANCE_ERROR = -14,
    VCENC_HRD_ERROR = -15,
    VCENC_HW_RESET = -16
  } VCEncRet;

  /* Stream type for initialization */
  typedef enum
  {
    VCENC_BYTE_STREAM = 0,    /* NAL unit starts with hex bytes '00 00 00 01' */
    VCENC_NAL_UNIT_STREAM = 1 /* Plain NAL units without startcode */
  } VCEncStreamType;

  /* Level for initialization */
  typedef enum
  {
    VCENC_HEVC_LEVEL_1 = 30,
    VCENC_HEVC_LEVEL_2 = 60,
    VCENC_HEVC_LEVEL_2_1 = 63,
    VCENC_HEVC_LEVEL_3 = 90,
    VCENC_HEVC_LEVEL_3_1 = 93,
    VCENC_HEVC_LEVEL_4 = 120,
    VCENC_HEVC_LEVEL_4_1 = 123,
    VCENC_HEVC_LEVEL_5 = 150,
    VCENC_HEVC_LEVEL_5_1 = 153,
    VCENC_HEVC_LEVEL_5_2 = 156,
    VCENC_HEVC_LEVEL_6 = 180,
    VCENC_HEVC_LEVEL_6_1 = 183,
    VCENC_HEVC_LEVEL_6_2 = 186,

    /* H264 Defination*/
    VCENC_H264_LEVEL_1 = 10,
    VCENC_H264_LEVEL_1_b = 99,
    VCENC_H264_LEVEL_1_1 = 11,
    VCENC_H264_LEVEL_1_2 = 12,
    VCENC_H264_LEVEL_1_3 = 13,
    VCENC_H264_LEVEL_2 = 20,
    VCENC_H264_LEVEL_2_1 = 21,
    VCENC_H264_LEVEL_2_2 = 22,
    VCENC_H264_LEVEL_3 = 30,
    VCENC_H264_LEVEL_3_1 = 31,
    VCENC_H264_LEVEL_3_2 = 32,
    VCENC_H264_LEVEL_4 = 40,
    VCENC_H264_LEVEL_4_1 = 41,
    VCENC_H264_LEVEL_4_2 = 42,
    VCENC_H264_LEVEL_5 = 50,
    VCENC_H264_LEVEL_5_1 = 51,
    VCENC_H264_LEVEL_5_2 = 52
  } VCEncLevel;
  
  typedef struct frame_info {
      u32 frame_count;
      u32 qp;
      u32 frame_size;
      // Add other GOP-specific fields as needed
  } frame_info_t;

  #define GOP_ARRAY_SIZE 300

  /* Profile for initialization */
  typedef enum
  {
    VCENC_HEVC_MAIN_PROFILE = 0,
    VCENC_HEVC_MAIN_STILL_PICTURE_PROFILE = 1,
    VCENC_HEVC_MAIN_10_PROFILE = 2,
    /* H264 Defination*/
    VCENC_H264_BASE_PROFILE = 9,
    VCENC_H264_MAIN_PROFILE = 10,
    VCENC_H264_HIGH_PROFILE = 11,
    VCENC_H264_HIGH_10_PROFILE = 12,
  } VCEncProfile;

  /* Picture YUV type for initialization */
  typedef enum
  {
    VCENC_YUV420_PLANAR = 0,              /* YYYY... UUUU... VVVV...  */
    VCENC_YUV420_SEMIPLANAR,              /* YYYY... UVUVUV...        */
    VCENC_YUV420_SEMIPLANAR_VU,           /* YYYY... VUVUVU...        */
    VCENC_YUV422_INTERLEAVED_YUYV,        /* YUYVYUYV...              */
    VCENC_YUV422_INTERLEAVED_UYVY,        /* UYVYUYVY...              */
    VCENC_RGB565,                         /* 16-bit RGB 16bpp         */
    VCENC_BGR565,                         /* 16-bit RGB 16bpp         */
    VCENC_RGB555,                         /* 15-bit RGB 16bpp         */
    VCENC_BGR555,                         /* 15-bit RGB 16bpp         */
    VCENC_RGB444,                         /* 12-bit RGB 16bpp         */
    VCENC_BGR444,                         /* 12-bit RGB 16bpp         */
    VCENC_RGB888,                         /* 24-bit RGB 32bpp         */
    VCENC_BGR888,                         /* 24-bit RGB 32bpp         */
    VCENC_RGB101010,                      /* 30-bit RGB 32bpp         */
    VCENC_BGR101010,                       /* 30-bit RGB 32bpp         */
    VCENC_YUV420_PLANAR_10BIT_I010,         /* YYYY... UUUU... VVVV...  */
    VCENC_YUV420_PLANAR_10BIT_P010,         /* YYYY... UUUU... VVVV...  */
    VCENC_YUV420_PLANAR_10BIT_PACKED_PLANAR,         /* YYYY... UUUU... VVVV...  */
    VCENC_YUV420_10BIT_PACKED_Y0L2         /* Y0U0Y1a0a1Y2V0Y3a2a3Y4U1Y5a4a5Y6V1Y7a6a7... */
  } VCEncPictureType;

  /* Picture rotation for pre-processing */
  typedef enum
  {
    VCENC_ROTATE_0 = 0,
    VCENC_ROTATE_90R = 1, /* Rotate 90 degrees clockwise */
    VCENC_ROTATE_90L = 2,  /* Rotate 90 degrees counter-clockwise */
    VCENC_ROTATE_180R = 3  /* Rotate 180 degrees clockwise */
  } VCEncPictureRotation;

  /* Picture color space conversion (RGB input) for pre-processing */
  typedef enum
  {
    VCENC_RGBTOYUV_BT601 = 0, /* Color conversion according to BT.601 */
    VCENC_RGBTOYUV_BT709 = 1, /* Color conversion according to BT.709 */
    VCENC_RGBTOYUV_USER_DEFINED = 2   /* User defined color conversion */
  } VCEncColorConversionType;
  /* Picture type for encoding */
  typedef enum
  {
    VCENC_INTRA_FRAME = 0,
    VCENC_PREDICTED_FRAME = 1,
    VCENC_BIDIR_PREDICTED_FRAME = 2,
    VCENC_NOTCODED_FRAME  /* Used just as a return value */
  } VCEncPictureCodingType;

  /* Reference picture mode for reading and writing */
  typedef enum
  {
    VCENC_NO_REFERENCE_NO_REFRESH = 0,
    VCENC_REFERENCE = 1,
    VCENC_REFRESH = 2,
    VCENC_REFERENCE_AND_REFRESH = 3
  } VCEncRefPictureMode;

  /*------------------------------------------------------------------------------
      3. Structures for API function parameters
  ------------------------------------------------------------------------------*/
  typedef struct
  {
    u32 *ctuOffset; /* point to a memory containing the total CU number by the end of each CTU */
    u8  *cuData; /* cu information of a picture output by HW */
  } VCEncHEVCCuOutData;

  typedef struct
  {
    u8   refIdx; /* reference idx in reference list */
    i16  mvX; /* horiazontal motion in 1/4 pixel */
    i16  mvY; /* vertical motion in 1/4 pixel */
  } VCEncHEVCMv;

/**
 * \brief Color description in the vui which coded in the sps(sequence parameter sets).
 * only valid when video signal type present flag in the vui is set.
 */
  typedef struct {
    u8 vuiColorDescripPresentFlag; /**< \brief Color description present in the vui.0- not present, 1- present */
    u8 vuiColorPrimaries;          /**< \brief Color's Primaries */
    u8 vuiTransferCharacteristics; /**< \brief Transfer Characteristics */
    u8 vuiMatrixCoefficients;      /**< \brief Matrix Coefficients */
  } VuiColorDescription;

  typedef struct
  {
    u8  cuLocationX; /* cu x coordinate relative to CTU */
    u8  cuLocationY; /* cu y coordinate relative to CTU */
    u8  cuSize; /*cu size. 8/16/32/64 */
    u8  cuMode; /* cu mode. 0:INTER; 1:INTRA; 2:IPCM */
    u32 cuSadCost;  /* cu sad cost */
    u8  interPredIdc; /* only for INTER cu. prediction direction. 0: by list0; 1: by list1; 2: bi-direction */
    VCEncHEVCMv mv[2];  /* only for INTER cu. motion information. mv[0] for list0 if it's valid; mv[1] for list1 if it's valid */
    u8  intraPartMode; /* only for INTRA cu. partition mode. 0:2Nx2N; 1: NxN */
    u8  intraPredMode[4];/* only for INTRA CU. prediction mode. 0: planar; 1: DC; 2-34: Angular in HEVC spec. intraPredMode[1~3] only valid for NxN */
  } VCEncHEVCCuInfo;

  /* Configuration info for initialization
   * Width and height are picture dimensions after rotation
   * Width and height are restricted by level limitations
   */
  typedef struct
  {
    VCEncStreamType streamType;   /* Byte stream / Plain NAL units */

    VCEncProfile profile; /* Main, Main Still or main10 */

    VCEncLevel level; /* Supported Level */

    u32 width;           /* Encoded picture width in pixels, multiple of 2 */
    u32 height;          /* Encoded picture height in pixels, multiple of 2 */
    u32 frameRateNum;    /* The stream time scale, [1..1048575] */
    u32 frameRateDenom;  /* Maximum frame rate is frameRateNum/frameRateDenom
                              * in frames/second. The actual frame rate will be
                              * defined by timeIncrement of encoded pictures,
                              * [1..frameRateNum] */
    u32 refFrameAmount; /* Amount of reference frame buffers, [0..4]
                               * 0 = only I frames are encoded.
                               * 1 = gop size is 1 and interlacedFrame =0,
                               * 2 = gop size is 1 and interlacedFrame =1, 
                               * 2 = gop size is 2 or 3,
                               * 3 = gop size is 4,5,6, or 7,
                               * 4 = gop size is 8*/
    u32 strongIntraSmoothing;       /* 0 = Normal smoothing,
                                         * 1 = Strong smoothing. */

                      
    u32 compressor;       /*Enable/Disable Embedded Compression
                                              0 = Disable Compression
                                              1 = Only Enable Luma Compression
                                              2 = Only Enable Chroma Compression
                                              3 = Enable Both Luma and Chroma Compression*/
    u32 interlacedFrame;   /*0 = progressive frame; 1 = interlace frame  */
    
    u32 bitDepthLuma;     /*luma sample bit depth of encoded bit stream, 8 = 8 bits, 9 = 9 bits, 10 = 10 bits  */
    u32 bitDepthChroma;  /*chroma sample bit depth of encoded bit stream,  8 = 8 bits, 9 = 9 bits, 10 = 10 bits */
    u32 enableOutputCuInfo;  /* 1 to enable CU information dumping */
    u32 maxTLayers; /*max number Temporal layers*/

    i32 codecH264;     /* enable H264 encoding instead of HEVC */
    i32 codecDummy;    /* enable standalone pre-processing */

    u32 exp_of_alignment; /* input alignment exp */
    u32 refAlignmentExp; /* reference alignment exp */

    /* AXI alignment */
    u32 AXIAlignment; // bit[31:28] AXI_burst_align_wr_common
                      // bit[27:24] AXI_burst_align_wr_stream
                      // bit[23:20] AXI_burst_align_wr_chroma_ref
                      // bit[19:16] AXI_burst_align_wr_luma_ref
                      // bit[15:12] AXI_burst_align_rd_common
                      // bit[11: 8] AXI_burst_align_rd_prp
                      // bit[ 7: 4] AXI_burst_align_rd_ch_ref_prefetch
                      // bit[ 3: 0] AXI_burst_align_rd_lu_ref_prefetch

    /* AXI outstanding num */
    u32 AXIreadOutstandingNum;
    u32 AXIwriteOutstandingNum;
   } VCEncConfig;

  /* Defining rectangular macroblock area in encoder picture */
  typedef struct
  {
    u32 enable;         /* [0,1] Enables this area */
    u32 top;            /* Top macroblock row inside area [0..heightMbs-1] */
    u32 left;           /* Left macroblock row inside area [0..widthMbs-1] */
    u32 bottom;         /* Bottom macroblock row inside area [top..heightMbs-1] */
    u32 right;          /* Right macroblock row inside area [left..widthMbs-1] */
  } VCEncPictureArea;

  typedef struct
  {
    u32 enable;
    u32 format;
    u32 alpha;
    u32 xoffset;
    u32 cropXoffset;
    u32 yoffset;
    u32 cropYoffset;
    u32 width;
    u32 cropWidth;
    u32 height;
    u32 cropHeight;
    u32 Ystride;
    u32 UVstride;
    u32 bitmapY;
    u32 bitmapU;
    u32 bitmapV;
  } VCEncOverlayArea;

  /* Coding control parameters */
  typedef struct
  {
    u32 sliceSize;       /* Slice size in macroblock rows,
                              * 0 to encode each picture in one slice,
                              * [0..height/ctu_size]
                              */
    u32 seiMessages;     /* Insert picture timing and buffering
                              * period SEI messages into the stream,
                              * [0,1]
                              */


    u32 vuiVideoFullRange;  /* Input video signal sample range, [0,1]
                              * 0 = Y range in [16..235],
                              * Cb&Cr range in [16..240]
                              * 1 = Y, Cb and Cr range in [0..255]
                              */
    u32 disableDeblockingFilter;    /* 0 = Filter enabled,
                                         * 1 = Filter disabled,
                                         * 2 = Filter disabled on slice edges */
    i32 tc_Offset;                  /* deblock parameter, tc_offset */

    i32 beta_Offset;                /* deblock parameter, beta_offset */


    u32 enableDeblockOverride;      /* enable deblock override between slice*/
    u32 deblockOverride;            /* flag to indicate whether deblock override between slice */

    u32 enableSao;                  /* Enable SAO */

    u32 enableScalingList;          /* Enabled ScalingList */

    u32 sampleAspectRatioWidth; /* Horizontal size of the sample aspect
                                     * ratio (in arbitrary units), 0 for
                                     * unspecified, [0..65535]
                                     */
    u32 sampleAspectRatioHeight;    /* Vertical size of the sample aspect ratio
                                         * (in same units as sampleAspectRatioWidth)
                                         * 0 for unspecified, [0..65535]
                                         */
    u32 enableCabac;      /* [0,1] H.264 entropy coding mode, 0 for CAVLC, 1 for CABAC */
    u32 cabacInitFlag;    /* [0,1] CABAC table initial flag */
    u32 cirStart;           /* [0..mbTotal] First macroblock for
                                   Cyclic Intra Refresh */
    u32 cirInterval;        /* [0..mbTotal] Macroblock interval for
                                   Cyclic Intra Refresh, 0=disabled */

    i32 pcm_enabled_flag;               /* enable PCM encoding */
    i32 pcm_loop_filter_disabled_flag;  /* disable deblock filter for IPCM, 0=enabled, 1=disabled */
    VCEncPictureArea intraArea;   /* Area for forcing intra macroblocks */
    VCEncPictureArea ipcm1Area;   /* 1st Area for forcing IPCM macroblocks */
    VCEncPictureArea ipcm2Area;   /* 2st Area for forcing IPCM macroblocks */
    VCEncPictureArea roi1Area;    /* Area for 1st Region-Of-Interest */
    VCEncPictureArea roi2Area;    /* Area for 2nd Region-Of-Interest */
    i32 roi1DeltaQp;                /* [-30..0] QP delta value for 1st ROI */
    i32 roi2DeltaQp;                /* [-30..0] QP delta value for 2nd ROI */

    u32 fieldOrder;         /* Field order for interlaced coding,
                                   0 = bottom field first, 1 = top field first */
    i32 chroma_qp_offset;    /* chroma qp offset */

    u32 roiMapDeltaQpEnable;          /*0 = ROI map disabled, 1 = ROI map enabled.*/
    u32 roiMapDeltaQpBlockUnit;         /* 0-64x64,1-32x32,2-16x16,3-8x8*/
    u32 ipcmMapEnable;                /* 0 = IPCM map disabled,  1 = IPCM map enabled */

    //wiener denoise parameters

    u32 noiseReductionEnable; /*0 = disable noise reduction; 1 = enable noise reduction */
    u32 noiseLow; /* valid value range :[1,30] , default: 10 */
    u32 firstFrameSigma; /* valid value range :[1,30] , default :11*/
    
    u32 gdrDuration; /*how many pictures it will take to do GDR, if 0, not do GDR*/

    i32 codecH264;     /* enable H264 encoding instead of HEVC */

    /* for low latency */
    u32 inputLineBufEn;            /* enable input image control signals */
    u32 inputLineBufLoopBackEn;    /* input buffer loopback mode enable */
    u32 inputLineBufDepth;         /* input buffer depth in mb lines */
    u32 inputLineBufHwModeEn;        /* hw handshake*/
    EncInputLineBufCallBackFunc inputLineBufCbFunc;  /* callback function */
    void *inputLineBufCbData;     /* callback function data */

  /** \brief The color description in the VUI.
   *  \n For details, see Section <em> \ref ss_vui</em>. */
    VuiColorDescription vuiColorDescription;

  /** \brief Whether to present the video signal type in the VUI flag.
    * \n <b>0</b> (default): do not present
    * \n <b>1</b>: present
    * \n For more information about VUI, see Section <em> \ref ss_vui</em>. */
    u32 vuiVideoSignalTypePresentFlag;

  /** \brief The video format in the VUI. For details, see Section <em> \ref ss_vui</em>.
    * \n <b>0</b>: component
    * \n <b>1</b>: PAL
    * \n <b>2</b>: NTSC
    * \n <b>3</b>: SECAM
    * \n <b>4</b>: MAC
    * \n <b>5</b> (default): UNDEF */
    u32 vuiVideoFormat;
    u32 resendParamSet; /* Resend vps/pps/sps before each IDR frame */

  } VCEncCodingCtrl;

    typedef struct qp_smooth_settings {
    i32 qp_delta;
    i32 qp_delta_limit;
    u32 qp_delta_step;
    u32 qp_delta_limit_step;
    u32 q_step_divisor;
    float alpha;
  } qp_smooth_settings;

  typedef struct gop_anomaly_bitrate_adjuster {
    u32 enable;                /* Enable/disable smooth bitrate adjustment, [0,1] */
    float high_threshold;      /* High threshold for GOP frame analysis */
    float low_threshold;       /* Low threshold for GOP frame analysis */
    float max_factor;          /* Maximum target bitrate factor */
    float factor;              /* Bitrate adjustment factor */
  } gop_anomaly_bitrate_adjuster;

  /* Rate control parameters */
  typedef struct
  {
    u32 pictureRc;       /* Adjust QP between pictures, [0,1] */
    u32 ctbRc;           /* Adjust QP between Lcus, [0,1] */ //CTB_RC
    u32 blockRCSize;    /*size of block rate control : 2=16x16,1= 32x32, 0=64x64*/
    u32 pictureSkip;     /* Allow rate control to skip pictures, [0,1] */
    i32 qpHdr;           /* QP for next encoded picture, [-1..51]
                              * -1 = Let rate control calculate initial QP
                              * This QP is used for all pictures if
                              * HRD and pictureRc and mbRc are disabled
                              * If HRD is enabled it may override this QP
                              */
    u32 qpMin;           /* Minimum QP for any picture, [0..51] */
    u32 qpMax;           /* Maximum QP for any picture, [0..51] */
    u32 bitPerSecond;    /* Target bitrate in bits/second, this is
                              * needed if pictureRc, mbRc, pictureSkip or
                              * hrd is enabled [10000..60000000]
                              */

    u32 hrd;             /* Hypothetical Reference Decoder model, [0,1]
                              * restricts the instantaneous bitrate and
                              * total bit amount of every coded picture.
                              * Enabling HRD will cause tight constrains
                              * on the operation of the rate control
                              */
    u32 cvbr;           /* Mode that makes vbr more strict (closer to cbr) */
    u32 hrdCpbSize;      /* Size of Coded Picture Buffer in HRD (bits) */
    u32 hrdCbrFlag;      /* cbr_flag in vui */
    u32 gopLen;          /* Length for Group of Pictures, indicates
                              * the distance of two intra pictures,
                              * including first intra [1..300]
                              */
    i32 intraQpDelta;    /* Intra QP delta. intraQP = QP + intraQpDelta
                              * This can be used to change the relative quality
                              * of the Intra pictures or to lower the size
                              * of Intra pictures. [-12..12]
                              */
    u32 fixedIntraQp;    /* Fixed QP value for all Intra pictures, [0..51]
                              * 0 = Rate control calculates intra QP.
                              */
    i32 bitVarRangeI;/*variations over average bits per frame for I frame*/

    i32 bitVarRangeP;/*variations over average bits per frame for P frame*/

    i32 bitVarRangeB;/*variations over average bits per frame for B frame*/
    i32 tolMovingBitRate;/*tolerance of max Moving bit rate */
    i32 monitorFrames;/*monitor frame length for moving bit rate*/

    /* Smooth bitrate adjustment parameters */
    gop_anomaly_bitrate_adjuster gop_anomaly_bitrate_adjuster;
    
    /* QP smooth settings */
    qp_smooth_settings qp_smooth_settings; /* Settings for QP smoothing */
  } VCEncRateCtrl;

  typedef struct
  {
    i32 ref_pic; /* delta_poc of this reference picture relative to the poc of current picture */
    u32 used_by_cur; /* whether this reference picture used by current picture */
  } VCEncGopPicRps;

  typedef struct
  {
    u32 poc; /* picture order count within a GOP */
    i32 QpOffset; /* QP offset */
    double QpFactor; /* QP Factor */
    i32 temporalId;
    VCEncPictureCodingType codingType; /* picture coding type */
    u32 numRefPics; /* the number of reference pictures kept for this picture, the value should be within [0, VCENC_MAX_REF_FRAMES] */
    VCEncGopPicRps refPics[VCENC_MAX_REF_FRAMES]; /* reference picture sets for this picture*/
  } VCEncGopPicConfig;

  typedef struct
  {
    VCEncGopPicConfig *pGopPicCfg; /* Pointer to an array containing all used VCEncGopPicConfig */
    u8 size; /* the number of VCEncGopPicConfig pointed by pGopPicCfg, the value should be within [0, MAX_GOP_PIC_CONFIG_NUM] */
    u8 id;   /* the index of VCEncGopPicConfig in pGopPicCfg used by current picture, the value should be within [0, size-1] */
    u8 id_next;   /* the index of VCEncGopPicConfig in pGopPicCfg used by next picture, the value should be within [0, size-1] */
    i32 delta_poc_to_next;   /* the difference between poc of next picture and current picture */
    i32 ltrInterval; /*  Long term ref pic interval, 0 -- disable, >0 -- gap between 2 long term ref pics in display order */
  } VCEncGopConfig;

  /* Encoder input structure */
  typedef struct
  {
    u32 busLuma;         /* Bus address for input picture
                              * planar format: luminance component
                              * semiplanar format: luminance component
                              * interleaved format: whole picture
                              */
    u32 busChromaU;      /* Bus address for input chrominance
                              * planar format: cb component
                              * semiplanar format: both chrominance
                              * interleaved format: not used
                              */
    u32 busChromaV;      /* Bus address for input chrominance
                              * planar format: cr component
                              * semiplanar format: not used
                              * interleaved format: not used
                              */
    u32 timeIncrement;   /* The previous picture duration in units
                              * of 1/frameRateNum. 0 for the very first picture
                              * and typically equal to frameRateDenom for the rest.
                              */
    u32 *pOutBuf;        /* Pointer to output stream buffer */
    u32 busOutBuf;       /* Bus address of output stream buffer */
    u32 outBufSize;      /* Size of output stream buffer in bytes */
    u32 outBufFd;
    VCEncPictureCodingType codingType;    /* Proposed picture coding type,
                                                 * INTRA/PREDICTED
                                                 */
    i32 poc;      /* Picture display order count */
    VCEncGopConfig gopConfig; /* GOP configuration*/
    i32 gopSize;  /* current GOP size*/
    i32 gopPicIdx;   /* encoded order count of current picture within its GOP, shoule be in the range of [0, gopSize-1] */
    u32 roiMapDeltaQpAddr;   /* Pointer of QpDelta map   */

    /* for low latency */
    u32 lineBufWrCnt;    /* The number of MB lines already in input MB line buffer */

    i32 overlay_picture_cnt[MAX_OVERLAY_NUM]; /* overlayed picture count, to support rolling back*/

    /* Overlay */
  	ptr_t overlayInputYAddr[MAX_OVERLAY_NUM];
  	ptr_t overlayInputUAddr[MAX_OVERLAY_NUM];
  	ptr_t overlayInputVAddr[MAX_OVERLAY_NUM];
  	u32 overlayEnable[MAX_OVERLAY_NUM];


    /** \brief Write VUI timing info in SPS: 1=enable, 0=disable. */
    u32 vui_timing_info_enable;

    /** \page resendHeaders Resend VPS/SPS/PPS
     *
     * When VCEncIn.resendSPS or VCEncIn.resendSPS or VCEncIn.resendPPS is 1, the corresponding
     * parameter set will be inserted before the slice data.
     */
    u32 resendVPS;      /**< 0=NOT send VPS, 1= send VPS */
    u32 resendSPS;      /**< 0=NOT send SPS, 1= send SPS */
    u32 resendPPS;      /**< 0=NOT send PPS, 1= send PPS */
    u32 sendAUD;        /**< 0=NOT send AUD, 1= send AUD */
  } VCEncIn;

  /* Encoder output structure */
  typedef struct
  {
    VCEncPictureCodingType codingType;    /* Realized picture coding type,
                                                 * INTRA/PREDICTED/NOTCODED
                                                 */
    u32 streamSize;      /* Size of output stream in bytes */

    u32 *pNaluSizeBuf;   /* Output buffer for NAL unit sizes
                              * pNaluSizeBuf[0] = NALU 0 size in bytes
                              * pNaluSizeBuf[1] = NALU 1 size in bytes
                              * etc
                              * Zero value is written after last NALU.
                              */
    u32 numNalus;        /* Amount of NAL units */

    u32 busScaledLuma;   /* Bus address for scaled encoder picture luma   */
    u8 *scaledPicture;   /* Pointer for scaled encoder picture            */

    VCEncHEVCCuOutData cuOutData; /* Pointer for cu information output by HW */
  } VCEncOut;

  /* Input pre-processing */
  typedef struct
  {
    VCEncColorConversionType type;
    u16 coeffA;          /* User defined color conversion coefficient */
    u16 coeffB;          /* User defined color conversion coefficient */
    u16 coeffC;          /* User defined color conversion coefficient */
    u16 coeffE;          /* User defined color conversion coefficient */
    u16 coeffF;          /* User defined color conversion coefficient */
  } VCEncColorConversion;

  typedef struct
  {
    u32 origWidth;                          /* Input camera picture width */
    u32 origHeight;                         /* Input camera picture height*/
    u32 xOffset;                            /* Horizontal offset          */
    u32 yOffset;                            /* Vertical offset            */
    VCEncPictureType inputType;           /* Input picture color format */
    VCEncPictureRotation rotation;        /* Input picture rotation     */
    VCEncColorConversion colorConversion; /* Define color conversion
                                                   parameters for RGB input   */
    u32 scaledWidth;    /* Optional down-scaled output picture width,
                              multiple of 4. 0=disabled. [16..width] */
    u32 scaledHeight;   /* Optional down-scaled output picture height,
                              multiple of 2. [96..height]                    */

    u32 scaledOutput;                       /* Enable output of down-scaled
                                                   encoder picture.  */
    u32 scaledOutputFormat; /**< \brief 0:YUV422   1:YUV420SP*/
    u32 *virtualAddressScaledBuff;  /*virtual address of  allocated buffer in aplication for scaled picture.*/
    u32 busAddressScaledBuff; /*phyical address of  allocated buffer in aplication for scaled picture.*/
    u32 sizeScaledBuff;         /*size of allocated buffer in aplication for scaled picture. 
                                                          the size is not less than scaledWidth*scaledOutput*2 bytes */
    u32 alignment;

    /*Overlay area*/
    VCEncOverlayArea overlayArea[MAX_OVERLAY_NUM];
  } VCEncPreProcessingCfg;

  typedef struct
  {
    i32 chroma_qp_offset;           /* chroma qp offset */
    i32 tc_Offset;                  /* deblock parameter, tc_offset */
    i32 beta_Offset;                /* deblock parameter, beta_offset */
  } VCEncPPSCfg;
  

  /* Callback struct and function type. The callback is made by the encoder
   * when a slice is completed and available in the encoder stream output buffer. */

  typedef struct
  {
    u32 slicesReadyPrev;/* Indicates how many slices were completed at
                               previous callback. This is given because
                               several slices can be completed between
                               the callbacks. */
    u32 slicesReady;    /* Indicates how many slices are completed. */
    u32 nalUnitInfoNum;  /* Indicates how many information nal units are completed, including all kinds of sei information.*/                           
    u32 *sliceSizes;    /* Holds the size (bytes) of every completed slice. */
    u32 *pOutBuf;       /* Pointer to beginning of output stream buffer. */
    void *pAppData;     /* Pointer to application data. */
  } VCEncSliceReady;

  typedef void (*VCEncSliceReadyCallBackFunc)(VCEncSliceReady *sliceReady);

  /* Version information */
  typedef struct
  {
    u32 major;           /* Encoder API major version */
    u32 minor;           /* Encoder API minor version */
  } VCEncApiVersion;

  typedef struct
  {
    u32 swBuild;         /* Software build ID */
    u32 hwBuild;         /* Hardware build ID */
  } VCEncBuild;

  struct vcenc_buffer
  {
    struct vcenc_buffer *next;
    u8 *buffer;     /* Data store */
    u32 cnt;      /* Data byte cnt */
    u32 busaddr;      /* Data store bus address */
  };

  enum VCEncStatus
  {
    VCENCSTAT_INIT = 0xA1,
    VCENCSTAT_START_STREAM,
    VCENCSTAT_START_FRAME,
    VCENCSTAT_ERROR
  };

  /*------------------------------------------------------------------------------
      4. Encoder API function prototypes
  ------------------------------------------------------------------------------*/
  /* Version information */
  VCEncApiVersion VCEncGetApiVersion(void);
  VCEncBuild VCEncGetBuild(void);
  u32 VCEncGetRoiMapVersion(void);

  VCEncRet VCEncGetMaxSBPS(u32 level_index, u32 *max_sbps_out);
  VCEncRet VCEncGetMaxFS(u32 level_index, u32 *max_fs_out);

  /* Helper for input format bit-depths */
  u32 VCEncGetBitsPerPixel(VCEncPictureType type);

  u32 VCEncGetAlignedStride(int width, i32 input_format, u32 *luma_stride, u32 *chroma_stride,u32 input_alignment);

  /* Initialization & release */
  VCEncRet VCEncInit(VCEncConfig *config, VCEncInst *instAddr);
  VCEncRet VCEncRelease(VCEncInst inst);

  /*to get cycle number of finishing encoding current whole frame*/
  u32 VCEncGetPerformance(VCEncInst inst);

  /* Encoder configuration before stream generation */
  VCEncRet VCEncSetCodingCtrl(VCEncInst instAddr, const VCEncCodingCtrl *pCodeParams);
  VCEncRet VCEncGetCodingCtrl(VCEncInst inst, VCEncCodingCtrl *pCodeParams);

  /* Encoder configuration before and during stream generation */
  VCEncRet VCEncSetRateCtrl(VCEncInst inst, const VCEncRateCtrl *pRateCtrl);
  VCEncRet VCEncSetRateCtrlInternal(VCEncInst inst, const VCEncRateCtrl *pRateCtrl, u16 user_call);
  VCEncRet VCEncGetRateCtrl(VCEncInst inst, VCEncRateCtrl *pRateCtrl);

  VCEncRet VCEncSetPreProcessing(VCEncInst inst, const VCEncPreProcessingCfg *pPreProcCfg);
  VCEncRet VCEncGetPreProcessing(VCEncInst inst, VCEncPreProcessingCfg *pPreProcCfg);

  /* Encoder user data insertion during stream generation */
  VCEncRet VCEncSetSeiUserData(VCEncInst inst, const u8 *pUserData, u32 userDataSize);

  /* Stream generation */

  /* VCEncStrmStart generates the SPS and PPS. SPS is the first NAL unit and PPS
   * is the second NAL unit. NaluSizeBuf indicates the size of NAL units.
   */
  VCEncRet VCEncStrmStart(VCEncInst inst, const VCEncIn *pEncIn, VCEncOut *pEncOut);

  /* VCEncStrmEncode encodes one video frame. If SEI messages are enabled the
   * first NAL unit is a SEI message. When MVC mode is selected first encoded
   * frame belongs to view=0 and second encoded frame belongs to view=1 and so on.
   * When MVC mode is selected a prefix NAL unit is generated before view=0 frames.
   */
  VCEncRet VCEncStrmEncode(VCEncInst inst, const VCEncIn *pEncIn,
                               VCEncOut *pEncOut,
                               VCEncSliceReadyCallBackFunc sliceReadyCbFunc,
                               void *pAppData);

  /* VCEncStrmEnd ends a stream with an EOS code. */

  VCEncRet VCEncStrmEnd(VCEncInst inst, const VCEncIn *pEncIn, VCEncOut *pEncOut);

  /*
  The function analyzes a completed GOP (Group of Pictures) to determine if the bitrate needs adjustment to achieve more consistent frame sizes and smoother video quality.
  Parameters:
    user_bitrate: Original bitrate set by user
    frame_array: Array containing frame information for the GOP
    gopLen: Length of the GOP
    target_bitrate: Current target bitrate
    output_bitrate: Pointer to store the new adjusted bitrate
    gop_anomaly_bitrate_adjuster: Structure containing smooth adjustment thresholds and factors
  */
  VCEncRet ProcessGOPFrames(u32 user_bitrate, frame_info_t *frame_array, u32 gopLen, u32 target_bitrate, u32 *output_bitrate, 
                          const gop_anomaly_bitrate_adjuster *gop_anomaly_bitrate_adjuster);

  /*  internal encoder testing */
  VCEncRet VCEncSetTestId(VCEncInst inst, u32 testId);

  /*PPS config*/
  VCEncRet VCEncCreateNewPPS(VCEncInst inst, const VCEncPPSCfg *pPPSCfg, i32* newPPSId);
  VCEncRet VCEncModifyOldPPS(VCEncInst inst, const VCEncPPSCfg *pPPSCfg, i32 ppsId);
  VCEncRet VCEncGetPPSData(VCEncInst inst,  VCEncPPSCfg *pPPSCfg, i32 ppsId);
  VCEncRet VCEncActiveAnotherPPS(VCEncInst inst, i32 ppsId);
  VCEncRet VCEncGetActivePPSId(VCEncInst inst,  i32* ppsId);

  /* low latency */
  /* Set valid input MB lines for encoder to work */
  VCEncRet VCEncSetInputMBLines(VCEncInst inst, u32 lines);

  /* Get encoded lines information from encoder */
  u32 VCEncGetEncodedMbLines(VCEncInst inst);
  

  /*------------------------------------------------------------------------------
       API Functions only valid for HEVC.
   ------------------------------------------------------------------------------*/
   /* Get the encoding information of a specified CU in a specified CTU */
   VCEncRet VCEncHEVCGetCuInfo(VCEncInst inst, VCEncHEVCCuOutData *pEncCuOutData,
                                      VCEncHEVCCuInfo *pEncCuInfo, u32 ctuNum, u32 cuNum);

   /*------------------------------------------------------------------------------
      5. Encoder API tracing callback function
  ------------------------------------------------------------------------------*/

  void VCEncTrace(const char *msg);

#ifdef __cplusplus
}
#endif

#endif
